import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class EffectExecuteManager {

	Map<Effect, EffectParam> effectPairs;

	public EffectExecuteManager() {

	}

	public EffectExecuteManager(Map<Effect, EffectParam> pairs) {
		this.effectPairs = pairs;
	}

	public static void main(String[] args) {
		/*
		 * Create the first image, effect param and effect object. 
		 */
		// Create ImageData object;
		ImageData image = new ImageDataImpl();
		// Create GreyEffectParam object;
		int grey = 2;
		GreyEffectParamImpl grepParam = new GreyEffectParamImpl(image, grey);

		Effect greyEffect = new GreyEffectImpl(grepParam);

		List <Effect> list = new ArrayList<Effect>();

		list.add(greyEffect);
		
		
		/**
		 * Create the second image, effect param and effect object. 
		 */
		// Create ImageData object;
		image = new ImageDataImpl();
		// Create ResizeEffectParam object;
		int width = 100;
		int height = 200;
		ResizeEffectParamImpl resizeParam = new ResizeEffectParamImpl(image, width, height);

		Effect resizeEffect = new ResizeEffectImpl(resizeParam);
		list.add(resizeEffect);
		
		// EffectExecuteManager eem = new EffectExecuteManager(pairs);
		 for(Effect effect : list){
			 try {
				 Thread t = new Thread(effect);
				 t.start();
			 }catch (Exception e) {
				 System.out.println("Check  log for exception."); 
			}
		 }
	}

	public Map<Effect, EffectParam> getEffectPairs() {
		return effectPairs;
	}

	public void setEffectPairs(Map<Effect, EffectParam> effectPairs) {
		this.effectPairs = effectPairs;
	}
}
