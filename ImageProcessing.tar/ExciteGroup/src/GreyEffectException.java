/*
 * Grey effect exception. 
 */
public class GreyEffectException extends EffectException {

	public GreyEffectException(String string) {
		super(string);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -4327327843152940349L;

}
