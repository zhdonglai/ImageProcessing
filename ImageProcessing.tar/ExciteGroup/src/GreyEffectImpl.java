
public class GreyEffectImpl implements GreyEffect {

	private EffectParam param;
	
	public GreyEffectImpl(){
		
	}
	
	public GreyEffectImpl(EffectParam param){
		System.out.println("Creating ResizeEffectImpl object. ");
		this.param = param;
	}
	public EffectParam getParam() {
		return param;
	}
	public void setParam(EffectParam param) {
		this.param = param;
	}

	@Override
	public void applyEffect(GreyEffectParam param) throws GreyEffectException {
		if ( param != null ){
			ImageData id = param.getImageData();
			synchronized (id) {
			System.out.println("Applying for the grey effect with Gray parameter given...  Grey value is: " + param.getGrey()); 
			}
		}
			
		else{
			throw new GreyEffectException("Null pointer exception.");
		}
	}

	@Override
	public void applyEffect(EffectParam param) throws EffectException {
		applyEffect((GreyEffectParam)param);
	}

	@Override
	public void run() {
		try {
			applyEffect(param);
		} catch (EffectException e) {
		 System.out.println("Find exception, please check log system. ");
			e.printStackTrace();
		}
	}
}
