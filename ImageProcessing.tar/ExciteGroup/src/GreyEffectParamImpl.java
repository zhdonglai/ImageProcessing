
public class GreyEffectParamImpl implements GreyEffectParam{
	private ImageData imageData;
	/**
	 * Grey effect specific value, say an int;
	 */
	int grey;
	
	public GreyEffectParamImpl(){
		imageData = null;
		grey = 0;
	}
	
	public GreyEffectParamImpl(ImageData imageData, int grey){
		System.out.println("Creating GreyEffectParamImpl object...");
		this.imageData = imageData;
		this.grey = grey;
	}

	public ImageData getImageData() {
		return imageData;
	}

	public void setImageData(ImageData imageData) {
		this.imageData = imageData;
	}

	public int getGrey() {
		return grey;
	}

	public void setGrey(int grey) {
		this.grey = grey;
	}
}
