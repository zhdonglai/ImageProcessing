
public interface EffectParam {
	void setImageData(ImageData imageData);
	ImageData getImageData();
}
