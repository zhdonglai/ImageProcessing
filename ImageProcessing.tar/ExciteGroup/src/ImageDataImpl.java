/*
 * Save the image data in this class. 
 */
public class ImageDataImpl implements ImageData {
	/*
	 * Suppose we use byte array to store image data. 
	 */
	byte [] imageData;
	
	public ImageDataImpl(){
		
	}
	public ImageDataImpl(byte [] imageData){
		this.imageData = imageData;
	}
	
	public byte[] getImageData() {
		return imageData;
	}
	
	public void setImageData(byte[] imageData) {
		this.imageData = imageData;
	}
}
