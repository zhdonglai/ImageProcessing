
public class ResizeEffectParamImpl implements ResizeEffectParam {
	private ImageData imageData;
	/**
	 * Grey effect specific value, say an int;
	 */
	int width;
	int height;
	
	public ResizeEffectParamImpl(){
		imageData = null;
		width = 0;
		height = 0;
	}
	
	public ResizeEffectParamImpl(ImageData imageData, int width, int height){
		System.out.println("Creating resizeEffectParamImpl object...");
		this.imageData = imageData;
		this.width = width;
		this.height = height;
	}

	public ImageData getImageData() {
		return imageData;
	}

	public void setImageData(ImageData imageData) {
		this.imageData = imageData;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}
}
