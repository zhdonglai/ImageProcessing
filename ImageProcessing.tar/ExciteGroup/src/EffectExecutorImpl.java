/**
 * Spawn a thread for each effect object and the corresponding data. 
 * @author donglaizhang
 *
 */

public class EffectExecutorImpl extends EffectExecutor {
	
	Effect effect;
	EffectParam param;
	
	public EffectExecutorImpl() {
	}
	public EffectExecutorImpl(Effect effect, EffectParam param) {
		this.effect = effect;
		this.param = param;
	}
	
	public void execute(){
		Thread t  = new Thread(this);
		t.start();
	}
	@Override
	public void run() {
		try {
			effect.applyEffect(param);
		} catch (EffectException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
