/**
 * An interface to represent an effect to be applied to an image.  
 * Define individual effect interface for each effect. 
 */

/**
 * 
 * @author Doug( Donglai Zhang)
 *
 */
public interface Effect extends Runnable {
	void applyEffect(EffectParam param) throws EffectException;
}
