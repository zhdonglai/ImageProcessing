/*
 * Define grey effect parameter 
 */
public interface GreyEffectParam extends EffectParam {
	public int getGrey();
	public void setGrey(int grey);
}
