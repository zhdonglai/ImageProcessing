/*
 * This interface defines an abstract source of image data. 
 */
public interface ImageData {

}
