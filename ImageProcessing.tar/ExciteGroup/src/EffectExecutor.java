import java.util.Map;

/**
 * Each EffectExecutor implements a Runnable interface. 
 * So they can be run concurrently or parallel. 
 * @author Doug (Donglai) Zhang
 *
 */
public abstract class  EffectExecutor implements Runnable{
	//Each EffectExecutor will need to hold a list of Effect object to call. 
	Map <Effect, EffectParam > effectPairs;
	public EffectExecutor(){
		
	}
	public EffectExecutor(Map <Effect, EffectParam> effectPairs){
		this.effectPairs = effectPairs;
	}
	//Implement later. 
	public abstract void run();
}
