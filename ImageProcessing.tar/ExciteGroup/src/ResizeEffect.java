/*
 * Define individual effect interface for each effect. 
 */
public interface ResizeEffect extends Effect { 
	void applyEffect(ResizeEffectParam param) throws ResizeEffectException;
}
