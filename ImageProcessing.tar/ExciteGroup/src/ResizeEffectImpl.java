/*
 * Information of the effect parameter are saved in param. 
 */

public class ResizeEffectImpl implements ResizeEffect {
	private EffectParam param;

	public ResizeEffectImpl(){
	}
	
	public ResizeEffectImpl(EffectParam param){
		System.out.println("Creating ResizeEffectImpl object. ");
		this.param = param;
	}
	
	@Override
	public void applyEffect(ResizeEffectParam param) throws ResizeEffectException {
		if ( param != null ){
			ImageData id = param.getImageData();
			synchronized(id){
				System.out.println("Applying for the Resize effect with Resize parameter given...  Width is: " + param.getWidth());
		   }
		}else{
			System.out.println("Null pointer exception applying resize effect.."); 
		}
	}

	@Override
	public void applyEffect(EffectParam param) throws EffectException {
		applyEffect((ResizeEffectParam)param);
	}

	public EffectParam getParam() {
		return param;
	}
	public void setParam(EffectParam param) {
		this.param = param;
	}
	@Override
	public void run() {
		try {
			applyEffect(param);
		} catch (EffectException e) {
		 System.out.println("Find exception, please check log system. ");
			e.printStackTrace();
		}		
	}
}
