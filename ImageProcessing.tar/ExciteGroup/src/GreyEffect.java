/*
 * Define individual effect interface for each effect. 
 */
public interface GreyEffect extends Effect {
	void applyEffect(GreyEffectParam param) throws GreyEffectException;
} 
