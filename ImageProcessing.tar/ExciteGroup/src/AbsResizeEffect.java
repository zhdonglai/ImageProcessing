
public abstract class AbsResizeEffect implements ResizeEffect {

	private ImageData image; 
	
	AbsResizeEffect(ImageData image){
		this.image = image;
	}	
}
